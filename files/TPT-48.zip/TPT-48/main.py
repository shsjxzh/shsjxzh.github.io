import os
from easydict import EasyDict
import matplotlib.pyplot as plt
import torch
import numpy as np
import random
import pickle
from model import *

# from configs.config import opt
# start the gda coding
# from configs.config_GDA import opt
# from configs.config_DANN import opt
# from configs.config_GDA_classify import opt
# from configs.config_GDA_classify_22 import opt

from configs.config_GDA_temp import opt

from data_loader.data_loader import WeatherDataLoader

dataloader = WeatherDataLoader(opt)
np.random.seed(opt.seed)
random.seed(opt.seed)
torch.manual_seed(opt.seed)

if opt.bound_prediction:
    opt.norm_min = dataloader.norm_min
    opt.norm_max = dataloader.norm_max

if opt.model == "SO":
    from model.model import SO as Model
elif opt.model == "DANN":
    from model.model import DANN as Model
elif opt.model == "GDA":
    from model.model import GDA as Model
elif opt.model == "CDANN":
    from model.model import CDANN as Model
elif opt.model == "ADDA":
    from model.model import ADDA as Model
elif opt.model == "MDD":
    from model.model import MDD as Model 
model = Model(opt).to(opt.device).double()

# train
for epoch in range(opt.num_epoch):
    model.learn(epoch, dataloader)
    if (epoch + 1) % opt.save_interval == 0 or (epoch + 1) == opt.num_epoch:
        model.save()
        # model.visualize_D()
        # model.visualize_F()
        # model.visualize_E()
    if (epoch + 1) % opt.test_interval == 0 or (epoch + 1) == opt.num_epoch:    
        model.test(epoch, dataloader)
    