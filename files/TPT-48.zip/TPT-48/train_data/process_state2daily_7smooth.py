import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 

def get_date_list(begin_date,end_date):
    date_list = [x.strftime('%Y-%m-%d') for x in list(pd.date_range(start=begin_date, end=end_date))]
    return date_list

data = pd.read_pickle('data/processed_us_confirmed.pkl')

states = data.columns.values
print(states)

data_new_shift = data.shift(1).replace(np.nan, 0)
daily_cases = data - data_new_shift
print(daily_cases)

ave_7_case = daily_cases

for i in range(1, 7):
    print(i)
    ave_7_case += daily_cases.shift(i).replace(np.nan, 0)

ave_7_case /= 7
print(ave_7_case)

ave_7_case.to_csv("data/daily_7smooth_us_confirmed.csv")
ave_7_case.to_pickle("data/daily_7smooth_us_confirmed2.pkl", protocol=4)

# ## TODO: 保存每个州的数据，save_data[state][date] 能够访问到一天的case数量
# print(processed_data)

# processed_data = pd.DataFrame(processed_data, index=dates)
# # plt.plot(processed_data['California'])
# # plt.show()
# processed_data.to_csv("processed_us_confirmed.csv")
# processed_data.to_pickle("processed_us_confirmed.pkl")
# print(pd.read_pickle("processed_us_confirmed.pkl"))