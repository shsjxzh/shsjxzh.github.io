# truncate the day for I need
# consider the population

import numpy as np
import pandas as pd
import pickle

def write_pickle(data, name):
    with open(name,'wb') as f:
        # the default protocol level is 4
        pickle.dump(data, f)

def get_date_list(begin_date,end_date):
    date_list = [x.strftime('%Y-%m-%d') for x in list(pd.date_range(start=begin_date, end=end_date))]
    return date_list


cases_data = pd.read_pickle("data/daily_7smooth_us_confirmed.pkl")
# choose the date for expr 
st_date = "2020-03-13"
ed_date = "2020-11-11"
dates = get_date_list(st_date, ed_date)

# print(len(dates))
cases_data = cases_data.loc[dates, :]

# population & state name
population_data = pd.read_csv("data/population.csv", header=None)
population_data = dict(zip(population_data[0], population_data[1]))
abbrv_data = pd.read_csv("usa_map/Abbre.csv")
# abbrv = abbrv_data['Abbr']
state_name = abbrv_data['State']
abbrv_data = dict(zip(abbrv_data['State'], abbrv_data['Abbr']))

new_data = dict()
# print(cases_data)
for state in state_name:
    abbrv = abbrv_data[state]
    new_data[abbrv] = (cases_data[state] * 10000 / population_data[state]).to_numpy()

# print(new_data)
write_pickle(new_data, "data/7sm_popu_us_confirmed.pkl")