import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 
import networkx as nx

def get_date_list(begin_date,end_date):
    date_list = [x.strftime('%Y-%m-%d') for x in list(pd.date_range(start=begin_date, end=end_date))]
    return date_list

def usa_map_draw(choosen_nodes):
    a = pd.read_csv("usa_map/USAGraphPos.csv")
    pos = dict()
    for tup in zip(a['state'], a['pos_x'], a['pos_y']):
        tup_tmp = [float(tup[1]), float(tup[2])]
        pos[tup[0]] = np.array(tup_tmp, dtype=np.float)

    g = nx.read_adjlist('usa_map/usa_map.txt')
    nodes = g.nodes()
    color_map = dict(zip(nodes, ['tab:blue'] * len(nodes)))
    for node in choosen_nodes:
        color_map[node] = 'r'

    # print(pos)
    nx.draw(g, pos, with_labels=True, node_color=color_map.values())
    plt.savefig("plot_pic/1.jpg",dpi=300, bbox_inches='tight', pad_inches=0)
    plt.show()


# cases_data = pd.read_pickle("processed_us_confirmed.pkl")
cases_data = pd.read_pickle("data/daily_7smooth_us_confirmed.pkl")
# choose the date for 
st_date = "2020-03-13"
ed_date = "2020-11-11"
dates = get_date_list(st_date, ed_date)
cases_data = cases_data.loc[dates, :]


population_data = pd.read_csv("data/population.csv", header=None)
population_data = dict(zip(population_data[0], population_data[1]))
abbrv_data = pd.read_csv("usa_map/Abbre.csv")
abbrv_data = dict(zip(abbrv_data['Abbr'], abbrv_data['State']))

# states = ['California', 'Nevada', 'Oregon', 'Washington']
# states = ['New York', 'Pennsylvania', 'New Jersey', 'Massachusetts']
states_abbrv = ['CA', 'NV', 'WA', 'OR']
# ['NY', 'MA', 'PA', 'NJ']
# ['WI', 'MI', 'OH', 'PA']
# ['AL', 'GA', 'FL']
# ['WY', 'CO', 'KS', 'NE'] 
# ['CA', 'NY', 'TX', 'SC']
# ['NY', 'PA', 'MD', 'VA']
# ['OR', 'ID', 'WY', 'NE', 'IA', 'IL']
# ['TN', 'VA', 'GA', 'NC', 'AL', 'KY']
# ['WA', 'TX', 'NY', 'SC']

states = [abbrv_data[i] for i in states_abbrv]

usa_map_draw(states_abbrv)

colors = ['r', 'b', 'y', 'g', 'm', 'c']

# print(population_data)

for state, color in zip(states, colors):
    plt.plot(cases_data[state], color + '-')

plt.legend(states)
plt.xticks([])
plt.title("confirmed cases daily")
plt.savefig("plot_pic/2.jpg",dpi=300, bbox_inches='tight')
plt.show()

for state, color in zip(states, colors):
    plt.plot(cases_data[state] * 10000 / population_data[state], color + '-')

plt.legend(states)
plt.xticks([])
plt.title("confirmed cases daily / 10000 population")
plt.savefig("plot_pic/3.jpg",dpi=300, bbox_inches='tight')
plt.show()