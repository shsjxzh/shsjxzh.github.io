import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 

def get_date_list(begin_date,end_date):
    date_list = [x.strftime('%Y-%m-%d') for x in list(pd.date_range(start=begin_date, end=end_date))]
    return date_list

data = pd.read_csv('data/us_confirmed.csv')

# test
# states = data['Province/State']
# states = states.drop_duplicates()
# states = states.tolist()
# print(states)
# 48 states + Columbia
states = [
    'Alabama', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Wyoming', 
    'Delaware', 'District of Columbia', 'Florida', 'Georgia', 'Idaho', 'Illinois', 'Indiana', 
    'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 
    'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 
    'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 
    'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 
    'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 
]

start_date = '2020-01-22'
# start_date = '2020-11-01'
end_date = '2020-11-11'
dates = get_date_list(start_date, end_date)

# allocate the memory for processed data

index_len = len(dates)
column_len = len(states)
# processed_data = pd.DataFrame(np.zeros((index_len, column_len)), index=dates, columns=states)
# processed_data = pd.DataFrame(index=dates)
processed_data = dict()

for state in states:
    cases = []

    state_data = data[data['Province/State'] == state]
    for date in dates:
        state_case_confirmed = state_data[data['Date'] == date]
        # print(state_case_confirmed)
        today_cases = state_case_confirmed['Case'].sum() # / population[state]
        # print(today_cases)
        cases.append(today_cases)
        # processed_data[state][date] = today_cases
        # processed_data.loc[state, date] = today_cases

    # fig, ax = plt.subplots()
    # plt.bar(dates, cases)
    processed_data[state] = cases
    # rects1 = ax.bar(dates, cases)
    # autolabel(rects1)
    # print(cases)

# ## TODO: 保存每个州的数据，save_data[state][date] 能够访问到一天的case数量
# print(processed_data)

processed_data = pd.DataFrame(processed_data, index=dates)

# plt.plot(processed_data['California'])
# plt.show()
processed_data.to_csv("processed_us_confirmed.csv")
processed_data.to_pickle("processed_us_confirmed.pkl")
print(pd.read_pickle("processed_us_confirmed.pkl"))