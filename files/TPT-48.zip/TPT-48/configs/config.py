from easydict import EasyDict
import numpy as np
import pandas as pd
import networkx as nx
# set experiment configs
opt = EasyDict()

# I have already truncated the data and use cases / population!!
# # the start and end date
# opt.st_date = '2020-3-13'
# opt.ed_date = '2020-11-11'

# data source
opt.data_src = "train_data/data/7sm_popu_us_confirmed.pkl"

# dataset and data loading
opt.shuffle=True
opt.all_state_name = pd.read_csv("train_data/usa_map/Abbre.csv")['Abbr']
# opt.state2num = dict(zip(opt.all_states, range(len(opt.all_states))))
opt.src_domain = ['NJ','NY']
opt.tgt_domain = ['PA','MA']

opt.src_dmn_num = len(opt.src_domain)
opt.tgt_dmn_num = len(opt.tgt_domain)

opt.all_domain = opt.src_domain + opt.tgt_domain
opt.num_domain = len(opt.all_domain)
opt.state2num = dict(zip(opt.all_domain, range(opt.num_domain)))
# opt.num2state = dict(zip(range(opt.num_domain), opt.all_domain))

opt.src_domain_idx = [opt.state2num[i] for i in opt.src_domain]
opt.tge_domain_idx = [opt.state2num[i] for i in opt.tgt_domain]

# often used training setting
opt.batch_size = 10
opt.num_epoch = 500
opt.lr_e = 3e-5 # 1e-4
opt.lr_d = 3e-5
opt.outf = "dump"
opt.test_on_all_dmn = True # whethor test on all the domains or just target domain

opt.save_interval = 50
opt.test_interval = 50 # 20 # 5

# modules setting
opt.gamma = 100
opt.beta1 = 0.9
opt.weight_decay = 5e-4

opt.num_input = 1
opt.num_layer = 2    # how many blocks will the LSTM net has
opt.num_hidden = 512 # the hidden states for the lstm layer
opt.seq_len = 7      # seq_len day predict & 1 day test

opt.device = "cuda" # "cuda"
# print(opt.A)
