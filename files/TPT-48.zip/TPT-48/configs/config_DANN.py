from easydict import EasyDict
import numpy as np
import pandas as pd
import networkx as nx
# set experiment configs
opt = EasyDict()

# I have already truncated the data and use cases / population!!
# # the start and end date
# opt.st_date = '2020-3-13'
# opt.ed_date = '2020-11-11'

# data source
opt.data_src = "train_data/data/7sm_popu_us_confirmed.pkl"

# dataset and data loading
opt.shuffle=True
opt.all_state_name = pd.read_csv("train_data/usa_map/Abbre.csv")['Abbr']
# opt.state2num = dict(zip(opt.all_states, range(len(opt.all_states))))
opt.src_domain = ['NJ','NY']
opt.tgt_domain = ['MA','PA']

# opt.src_domain = ['VT','NH','ME','NY','MA','PA','NJ','CT','RI','WV','MD','DE']
# opt.tgt_domain = ['KY','VA','DC','TN','AL','GA','NC','FL','SC','MS']

opt.src_dmn_num = len(opt.src_domain)
opt.tgt_dmn_num = len(opt.tgt_domain)

opt.all_domain = opt.src_domain + opt.tgt_domain
opt.num_domain = len(opt.all_domain)
opt.state2num = dict(zip(opt.all_domain, range(opt.num_domain)))
# opt.num2state = dict(zip(range(opt.num_domain), opt.all_domain))

opt.src_domain_idx = [opt.state2num[i] for i in opt.src_domain]
opt.tge_domain_idx = [opt.state2num[i] for i in opt.tgt_domain]

# often used training setting
# G and D balance
opt.lambda_gan = 0
# opt.lambda_pred = 0
opt.batch_size = 10
opt.num_epoch = 500
opt.lr_e = 3e-5 # 1e-4
opt.lr_d = 3e-4
opt.lr_g = 1e-3
opt.outf = "dump"
opt.test_on_all_dmn = True # whethor test on all the domains or just target domain

opt.save_interval = 50
opt.test_interval = 20 # 20 # 5

# modules setting
opt.no_bn = True
opt.gamma = 100
opt.beta1 = 0.9
opt.weight_decay = 5e-4

opt.p = 0.4          # drop out rate

opt.num_input = 1    # the x data dimension
opt.num_layer = 1 # 2    # how many blocks will the LSTM net has
opt.num_hidden = 512 # the hidden states for the lstm layer and linear layer
opt.seq_len = 7      # seq_len day predict & 1 day test

opt.data_embed = 128 # the dim for data after the vetex embed and data embed concatenate

opt.nd_out = 2       # the output dimension of D
opt.nv_embed = 2     # the vertex embedding dimension


# sampling number
opt.sample_v = 4     # the sample number for d's training
opt.sample_v_g = 4   # the sample number for g's training

opt.device = "cuda" # "cuda"

# graph setting
opt.graph = nx.read_adjlist('train_data/usa_map/usa_map.txt')
opt.A = np.zeros((opt.num_domain, opt.num_domain))
for i in range(opt.num_domain):
    for j in range(i, opt.num_domain):
        if i == j or opt.graph.has_edge(opt.all_domain[i], opt.all_domain[j]):
            opt.A[i][j] = 1
            opt.A[j][i] = 1

print(opt.A)
# only for this!!
# opt.A[0][0] = 0
# opt.A[1][1] = 0