# Graph Relation Domain Adaptation

## Installation
    pip install -r requirements.txt
	
## Reference
If you find TPT-48 helpful, please consider citing:<br>
[Graph-Relational Domain Adaptation](http://wanghao.in/paper/ICLR22_GRDA.pdf)
```bib
@inproceedings{GRDA,
  title={Graph-Relational Domain Adaptation},
  author={Xu, Zihao and He, Hao and Lee, Guang-He and Wang, Yuyang and Wang, Hao},
  booktitle={International Conference on Learning Representations},
  year={2022}
}
```