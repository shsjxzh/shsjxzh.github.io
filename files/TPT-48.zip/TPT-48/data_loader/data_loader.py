import pandas as pd
import numpy as np
import torch
import pickle
from torch.utils.data import Dataset, DataLoader


from data_loader.utils import get_date_list

def read_pickle(name):
    with open(name, 'rb') as f:
        data = pickle.load(f)
    return data

class WeatherDataLoader():
    def __init__(self, opt):
        self.opt = opt
        self.src_domain = opt.src_domain
        self.tgt_domain = opt.tgt_domain
        self.raw_data = read_pickle(opt.data_src)
        self.group_len = opt.group_len
        self.all_states = self.opt.all_domain # self.src_domain + self.tgt_domain
        self.sudo_len = max([len(self.raw_data[state]) for state in self.all_states]) - self.group_len + 1
        self.all_mean, self.all_std = self.__norm__()
        # self.sudo_len = max([len(self.raw_data[state]) for state in self.all_states]) - self.opt.seq_len
        
        if self.opt.bound_prediction:
            self.max, self.min = self.__maxmin__()
            self.norm_max, self.norm_min = (self.max - self.all_mean) / self.all_std, (self.min - self.all_mean) / self.all_std
#             print(self.max)
#             print(self.min)
        

        self.train_datasets = [
            CovidTrainDataset(self.raw_data[state], 
                isSrc=(state in self.src_domain), 
                all_mean=self.all_mean, 
                all_std=self.all_std,
                domain_idx=self.opt.state2num[state],
                sudo_len=self.sudo_len,
                opt=opt) 
                for state in self.all_states
        ]

        if self.opt.test_on_all_dmn:
            # test on all domains
            self.test_datasets = [
                CovidTestDataset(self.raw_data[state], 
                    # isSrc=True, 
                    all_mean=self.all_mean, 
                    all_std=self.all_std,
                    domain_idx=self.opt.state2num[state],
                    # sudo_len=self.sudo_len,
                    opt=opt) 
                    for state in self.all_states
            ]
        else:
            # test only on target domain
            self.test_datasets = [
                CovidTestDataset(self.raw_data[state], 
                    # isSrc=True, 
                    all_mean=self.all_mean, 
                    all_std=self.all_std,
                    domain_idx=self.opt.state2num[state],
                    # sudo_len=self.sudo_len,
                    opt=opt) 
                    for state in self.tgt_domain
            ]
        
        self.train_data_loader = [
            DataLoader(dataset, 
                batch_size=opt.batch_size, 
                shuffle=opt.shuffle) 
                for dataset in self.train_datasets
        ]

        self.test_data_loader = [
            DataLoader(dataset, 
                batch_size=opt.batch_size, 
                shuffle=opt.shuffle) 
                for dataset in self.test_datasets
        ]
        
    def __maxmin__(self):
        tmp_max = -1e9
        tmp_min = 1e9
        for state in self.all_states:
            tmp_max = max(tmp_max, max(self.raw_data[state]))
            tmp_min = min(tmp_min, min(self.raw_data[state]))
        
        return tmp_max, tmp_min

    def __norm__(self):
        ## TODO: complete the whole code
        # be careful about the mean and variance calculation
        seq_len = self.opt.seq_len
        all_data = np.array([])
        for state in self.src_domain:
            # be sure that we delete more data (the last few days)
            all_data = np.append(all_data, self.raw_data[state][:(self.sudo_len + seq_len - 1)])
        for state in self.tgt_domain:
            # for 244 days only, without many special cases!
            tmp_data = self.raw_data[state]
            # for i in range(int((tmp_data.shape[0] // seq_len) / 2)):
            #     all_data = np.append(all_data, tmp_data[2 * seq_len * i: 2 * seq_len *i + 7])
            # group_len = seq_len + 1
            group_len = self.group_len
            data_group_num = tmp_data.shape[0] // group_len
            for i in range(data_group_num):
                all_data = np.append(all_data, tmp_data[i * group_len: i * group_len + seq_len])
                # all_data = np.append(all_data, tmp_data[i * group_len + group_len - 1])

        return all_data.mean(), all_data.std()
        # start here!


    def get_train_data(self):
        # this is return a iterator for the whole dataset
        return zip(*self.train_data_loader)

    def get_test_data(self):
        return zip(*self.test_data_loader)


class CovidTrainDataset(Dataset):
    def __init__(self, data, isSrc, all_mean, all_std, domain_idx, sudo_len, opt):
        self.data = (data - all_mean) / all_std
        self.domain_idx = domain_idx
        self.isSrc = isSrc
        self.seq_len = opt.seq_len

        self.sudo_len = sudo_len
        self.opt = opt
        self.group_len = opt.group_len

        if isSrc:
            # self.real_len = self.data.shape[0] - self.seq_len
            self.real_len = self.data.shape[0] - self.opt.group_len + 1
        else: 
            # Assume that we have 244 days data, so doesn't handle many speciall cases!
            # self.real_len = int((self.data.shape[0] // self.seq_len) / 2)
            self.real_len = self.data.shape[0] // self.opt.group_len # (self.seq_len + 1)


    def __len__(self):
        return self.sudo_len

    def __getitem__(self, idx):
        if self.isSrc:
            # x = torch.tensor(self.data[idx: idx + self.seq_len])
            # y = torch.tensor(self.data[idx + self.seq_len])
            x = self.data[idx: idx + self.seq_len]
            y = self.data[idx + self.seq_len: idx + self.seq_len * 2]
            # y = int(self.data[idx + self.seq_len] > self.data[idx + self.seq_len - 1])
            # y_value = abs(self.data[idx + self.seq_len] - self.data[idx + self.seq_len - 1])
            # y = int(self.data[idx + self.opt.group_len - 1] > self.data[idx + self.seq_len - 1])
            # y_value = abs(self.data[idx + self.opt.group_len - 1] - self.data[idx + self.seq_len - 1])
        else:
            if idx >= self.real_len:
                # idx = (idx + np.random.ra ndint(0,self.real_len)) % self.real_len
                idx = idx % self.real_len
                
            # x = self.data[idx * (self.seq_len + 1): idx * (self.seq_len + 1) + self.seq_len]
            # y = int(self.data[(self.seq_len + 1) * idx + self.seq_len] > self.data[(self.seq_len + 1) * idx + self.seq_len - 1])
            # y_value = abs(self.data[(self.seq_len + 1) * idx + self.seq_len] - self.data[(self.seq_len + 1) * idx + self.seq_len - 1])
            x = self.data[idx * self.group_len: idx * self.group_len + self.seq_len]
            y = self.data[idx * self.group_len + self.seq_len: idx * self.group_len + 2 * self.seq_len]
            # y = int(self.data[self.group_len * idx + self.group_len - 1] > self.data[self.group_len * idx + self.seq_len - 1])
            # y_value = abs(self.data[self.group_len * idx + self.group_len - 1] - self.data[self.group_len * idx + self.seq_len - 1])

        return x, y, idx, self.domain_idx # , y_value


class CovidTestDataset(Dataset):
    def __init__(self, data, all_mean, all_std, domain_idx, opt):
        self.data = (data - all_mean) / all_std
        self.domain_idx = domain_idx
        self.seq_len = opt.seq_len
        self.opt = opt
        self.group_len = opt.group_len

        # Assume that we have 244 days data, so doesn't handle many speciall cases!
        # self.real_len = int((self.data.shape[0] // self.seq_len) / 2)
        # the last test set will have 13 datapoints. be careful!
        # self.real_len = self.data.shape[0] // (self.seq_len + 1)
        self.real_len = self.data.shape[0] // opt.group_len

    def __len__(self):
        return self.real_len

    def __getitem__(self, idx):
        # x = self.data[2 * self.seq_len * idx : 2 * self.seq_len * idx + self.seq_len]
        # if idx == self.real_len - 1:
        #     # the last test set will have 13 datapoints. be careful!
        #     y = self.data[2 * self.seq_len * idx + self.seq_len:]
        # else:
        # for convenience, we only use 7 data for the last datapoints!
        # y = self.data[2 * self.seq_len * idx +  self.seq_len : 2 * self.seq_len * idx + 2 * self.seq_len]
        # x = self.data[idx * (self.seq_len + 1): idx * (self.seq_len + 1) + self.seq_len]
        # y = int(self.data[(self.seq_len + 1) * idx + self.seq_len] > self.data[(self.seq_len + 1) * idx + self.seq_len - 1])
        # y_value = abs(self.data[(self.seq_len + 1) * idx + self.seq_len] - self.data[(self.seq_len + 1) * idx + self.seq_len - 1])
        x = self.data[idx * self.group_len: idx * self.group_len + self.seq_len]
        y = self.data[idx * self.group_len + self.seq_len: idx * self.group_len + 2 * self.seq_len]
        # y = int(self.data[self.group_len * idx + self.group_len - 1] > self.data[self.group_len * idx + self.seq_len - 1])
        # y_value = abs(self.data[self.group_len * idx + self.group_len - 1] - self.data[self.group_len * idx + self.seq_len - 1])

        return x, y, idx, self.domain_idx # , y_value