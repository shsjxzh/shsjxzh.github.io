import numpy as np
from torch.utils.data import DataLoader, Dataset

class ToyDataset(Dataset):
    def __init__(self, data):
        self.data = data
    
    def __getitem__(self, idx):
        return self.data[idx]

    def __len__(self):
        return len(self.data)

a = ToyDataset(np.ones(5))
a_loader = DataLoader(
    dataset=a,
    batch_size=1
)
b = ToyDataset(np.ones(5)*3)
b_loader = DataLoader(
    dataset=b,
    batch_size=1
)

c = [a_loader, b_loader]

for i in zip(*c):
    x, y = i
    print(x)
    print(y)