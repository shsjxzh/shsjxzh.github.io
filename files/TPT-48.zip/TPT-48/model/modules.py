import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class Identity(nn.Module):
    def __init__(self):
        super(Identity, self).__init__()

    def forward(self, x):
        return x

# TODO: G now is a fixed embedding:
class GNet(nn.Module):
    def __init__(self, opt):
        super(GNet, self).__init__()

        # self.bias = torch.tensor(-1.9476923942565918).to(opt.device)# torch.randn(1).to(opt.device)
        # self.bias = torch.tensor(-2.0).to(opt.device)
        # self.bias.requires_grad=True

        # # self.weight = torch.tensor(2.4483554363250732).to(opt.device)# torch.randn(1).to(opt.device)
        # self.weight = torch.tensor(2.02).to(opt.device)
        # self.weight.requires_grad=True

        self.fc1 = nn.Linear(opt.num_domain, opt.num_hidden)
        # self.fc2 = nn.Linear(opt.nh, opt.nh)
        self.fc_final = nn.Linear(opt.num_hidden, opt.nv_embed)


    def forward(self, x):
        # the input for G is not changed, thus the dim is not changed
        re = x.dim() == 3
        if re:
            T, B, C = x.shape
            x = x.reshape(T * B, -1)
        # return torch.matmul(x.float(), self.G)
        # drop out:
        # p = self.opt.p
        # x = nn.Dropout(p=p)(x.float())
        x = F.relu(self.fc1(x.double()))
        # x = F.relu(self.fc1(x))
        
        
        # x = F.relu(self.fc1(x))
        # x = F.relu(self.fc2(x))
        # x = nn.Dropout(p=p)(x)
        x = self.fc_final(x)
        return x

class SeqFeatureNet(nn.Module):
    def __init__(self, opt):
        # the encoder
        super(SeqFeatureNet, self).__init__()
        self.opt = opt
        self.n_hidden = opt.num_hidden 
        self.n_input = opt.num_input
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len


        self.E_lstm = nn.LSTM(
            input_size=self.n_input,
            hidden_size=self.n_hidden,
            num_layers=self.n_layer,
            batch_first=False ## be careful about this batch first false!!!!
        )
    
    def __reset_hidden__(self, new_batch_size):
        self.hidden = (
            torch.zeros(self.n_layer, new_batch_size, self.n_hidden).double().to(self.opt.device), # h
            torch.zeros(self.n_layer, new_batch_size, self.n_hidden).double().to(self.opt.device)  # c
        )
    
    def forward(self, x):
        re = x.dim() == 4
        if re:
            Domain, B, Seq, Dim = x.shape
            x = x.reshape(Domain * B, Seq, Dim)

        x = x.transpose(0, 1)
        batch_size = x.shape[1]
        self.__reset_hidden__(new_batch_size=batch_size)

        _ , (hn, cn) = self.E_lstm(
            x,
            self.hidden
        )
        new_idx = list(range(self.n_layer-1, -1, -1))
        # print(new_idx)
        hn = hn[new_idx,:,:]
        cn = cn[new_idx,:,:]

        encode = torch.cat((hn, cn), dim=0)
        # print(encode.shape)

        if re:
            # (2 * num_layer, Domain, Batch Size, n_hidden)
            encode = encode.reshape(-1, Domain, B, self.n_hidden)
            # print("========")
            # print(encode.shape)
            return encode
        else:
            return encode

class GRUSeqFeatureNet(nn.Module):
    def __init__(self, opt):
        super(GRUSeqFeatureNet, self).__init__()
        self.opt = opt
        self.n_hidden = opt.num_hidden   
        self.nh_gru = opt.num_hidden     # be careful about this code!!
        self.n_input = opt.num_input     # the x's dim!
        self.nv_embed = opt.nv_embed     # the graph embeding's dim!
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len
        self.data_embed = opt.data_embed # the data dim for the input of LSTM
        self.p = opt.p                   # drop out rate

        self.fc1 = nn.Linear(self.n_input, self.n_hidden)
        self.fc2 = nn.Linear(self.n_hidden * 2, self.n_hidden * 2)
        self.fc3 = nn.Linear(self.n_hidden * 2, self.n_hidden * 2)
        self.fc_final = nn.Linear(self.n_hidden * 2, self.data_embed)

        self.fc1_var = nn.Linear(self.nv_embed, self.n_hidden)
        self.fc2_var = nn.Linear(self.n_hidden, self.n_hidden)

        self.E_lstm = nn.GRU(
            input_size=self.data_embed,
            hidden_size=self.nh_gru,
            num_layers=self.n_layer,
            batch_first=False ## be careful about this batch first false!!!!
        )

    def __reset_hidden__(self, new_batch_size):
        self.hidden = torch.zeros(self.n_layer, new_batch_size, self.nh_gru).double().to(self.opt.device) # h

    def forward(self, x, t):
        re = x.dim() == 4
        if re:
            Domain, B, Seq, Dim = x.shape
            x = x.reshape(Domain * B, Seq, Dim)
            t = t.reshape(Domain * B, -1)

        x = F.relu(self.fc1(x))
        t = F.relu(self.fc1_var(t))
        t = F.relu(self.fc2_var(t))

        t = t.unsqueeze(1)
        t = t.expand(Domain * B, Seq, -1)
        x = torch.cat((x, t), dim=-1)

        # main
        # drop out
        # x = nn.Dropout(p=self.p)(x)
        x = F.relu(self.fc2(x))
        # x = nn.Dropout(p=self.p)(x)
        x = F.relu(self.fc3(x))
        # x = nn.Dropout(p=self.p)(x)
        # x = F.relu(self.fc4(x))
        x = self.fc_final(x)

        # lstm
        x = x.transpose(0, 1)
        batch_size = x.shape[1]
        self.__reset_hidden__(new_batch_size=batch_size)

        output, hn = self.E_lstm(
            x,
            self.hidden
        )
        new_idx = list(range(self.n_layer-1, -1, -1))
        # print(new_idx)
        hn = hn[new_idx,:,:]

        # tmp will go to the one layer state
        encode = hn
        # encode = torch.cat((hn[0,:,:], hn[1,:,:]), dim=-1)

        if re:
            # origin: (Domain * Batch Size, 2 * grn_nh)
            encode = encode.reshape(Domain, B, -1)
            output = output.transpose(0, 1)

            # origin: (Domain * Batch size, seq len, hidden)
            # now: (Domain, Batch * seq len, hidden)
            output = output.reshape(Domain, B * self.seq_len, -1)
            # print("========")
            # print(encode.shape)
            return encode, output
        else:
            return encode, output


class DenseFeatureNet(nn.Module):
    def __init__(self, opt):
        # 
        # use fully connected layer to predict the data
        # 
        super(DenseFeatureNet, self).__init__()
        self.opt = opt
        self.n_hidden = opt.num_hidden   
        # self.nh_gru = int(opt.num_hidden / 2)         # be careful about this code!!
        self.n_input = opt.num_input * opt.seq_len      # the x's dim! * sequence length
        self.nv_embed = opt.nv_embed                    # the graph embeding's dim!
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len
        self.data_embed = opt.data_embed                # the data dim for the input of LSTM
        self.p = opt.p                                  # drop out rate

        self.fc1 = nn.Linear(self.n_input, self.n_hidden)
        self.fc2 = nn.Linear(self.n_hidden * 2, self.n_hidden * 2)
        self.fc3 = nn.Linear(self.n_hidden * 2, self.n_hidden * 2)
        self.fc4 = nn.Linear(self.n_hidden * 2, self.n_hidden * 2)
        self.fc_final = nn.Linear(self.n_hidden * 2, self.data_embed)

        self.fc1_var = nn.Linear(self.nv_embed, self.n_hidden)
        self.fc2_var = nn.Linear(self.n_hidden, self.n_hidden)

    def forward(self, x, t):
        re = x.dim() == 3
        if re:
            Domain, B, Dim = x.shape
            x = x.reshape(Domain * B, -1)
            t = t.reshape(Domain * B, -1)

        # print(x.shape)
        # print(t.shape)
        x = F.relu(self.fc1(x))
        t = F.relu(self.fc1_var(t))
        t = F.relu(self.fc2_var(t))

        # t = t.unsqueeze(1)
        # t = t.expand(Domain * B, Seq, -1)
        x = torch.cat((x, t), dim=1)

        # main
        # drop out
        # x = nn.Dropout(p=self.p)(x)
        x = F.relu(self.fc2(x))
        # x = nn.Dropout(p=self.p)(x)
        x = F.relu(self.fc3(x))
        # x = nn.Dropout(p=self.p)(x)
        x = F.relu(self.fc4(x))
        x = self.fc_final(x)

        if re:
            # origin: (Domain * Batch Size, Seq , dim)
            # now: domain, batch, seq * dim
            x = x.reshape(Domain, B, -1)
            return x
        else:
            return x


class DensePredNet(nn.Module):
    def __init__(self, opt):
        super(DensePredNet, self).__init__()
        self.opt = opt
        self.n_hidden = opt.num_hidden   
        # self.nh_gru = int(opt.num_hidden / 2)# be careful about this code!!
        self.data_embed = opt.data_embed # the data dim for the input of LSTM
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len
        self.input_size = 1 # self.data_embed
        self.p = opt.p                   # drop out rate

        # the predictor
        # I increase the data dimension for 
        self.fc1 = nn.Linear(self.data_embed, self.n_hidden)
        self.fc2 = nn.Linear(self.n_hidden, self.n_hidden)
        self.fc3 = nn.Linear(self.n_hidden, self.n_hidden)
        self.fc_final = nn.Linear(self.n_hidden, self.seq_len) # the output is the sequence length!!!!

        
    def forward(self, x):
        # print(x.shape)
        re = (x.dim() == 3)
        if re:
            Domain, B, my_hidden = x.shape
            x = x.reshape(Domain * B, -1)

        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        if self.opt.bound_prediction:
            x = torch.sigmoid(self.fc_final(x)) * (self.opt.norm_max - self.opt.norm_min) + self.opt.norm_min
        else:
            x = self.fc_final(x)

        if re:
            x = x.reshape(Domain, B, -1)
        return x


class DenseDNet(nn.Module):
    """
    Generate z' for connection loss
    """
    def __init__(self, opt):
        super(DenseDNet, self).__init__()
        nh = opt.num_hidden
        n_seq = opt.seq_len
        n_data_embed = opt.data_embed
        # nin = nh * 4   # 2 * hn and 2 * cn, * 4
        # nin = nh
        nin = n_seq * n_data_embed
        self.fc3 = nn.Linear(nin, nin)
        self.bn3 = nn.BatchNorm1d(nin)

        self.fc4 = nn.Linear(nin, nin)
        self.bn4 = nn.BatchNorm1d(nin)

        self.fc5 = nn.Linear(nin, nin)
        self.bn5 = nn.BatchNorm1d(nin)

        self.fc6 = nn.Linear(nin, nin)
        self.bn6 = nn.BatchNorm1d(nin)

        self.fc7 = nn.Linear(nin, nin)
        self.bn7 = nn.BatchNorm1d(nin)

        # be careful!! here use dimension of vertex embedding to encode; originally do not have this code
        # self.fc_final = nn.Linear(nh, opt.nt)
        self.fc_final = nn.Linear(nin, opt.nd_out)
        # self.fc_final = nn.Linear(nh, nh)

        if opt.no_bn:
            self.bn3 = Identity()
            self.bn4 = Identity()
            self.bn5 = Identity()
            self.bn6 = Identity()
            self.bn7 = Identity()
    
    def forward(self, x):
        re = x.dim() == 3

        if re:
            T, B, C = x.shape
            x = x.reshape(T * B, -1)

        x = F.relu(self.bn3(self.fc3(x)))
        x = F.relu(self.bn4(self.fc4(x)))
        x = F.relu(self.bn5(self.fc5(x)))
        x = F.relu(self.bn6(self.fc6(x)))
        x = F.relu(self.bn7(self.fc7(x)))

        # be careful!! here use the dimension of vertex embedding to encode; originally do not have this code
        x = self.fc_final(x)

        if re:
            return x.reshape(T, B, -1)
        else:
            return x


class GraphSeqFeatureNet(nn.Module):
    def __init__(self, opt):
        super(GraphSeqFeatureNet, self).__init__()
        self.opt = opt
        self.n_hidden = int(opt.num_hidden / 4) # be careful about this code!!
        self.n_input = opt.num_input     # the x's dim!
        self.nv_embed = opt.nv_embed     # the graph embeding's dim!
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len
        self.data_embed = opt.data_embed # the data dim for the input of LSTM

        self.fc1 = nn.Linear(self.n_input, self.n_hidden)
        self.fc2 = nn.Linear(self.n_hidden * 2, self.n_hidden * 2)
        self.fc3 = nn.Linear(self.n_hidden * 2, self.n_hidden * 2)
        self.fc_final = nn.Linear(self.n_hidden * 2, self.data_embed)

        self.fc1_var = nn.Linear(self.nv_embed, self.n_hidden)
        self.fc2_var = nn.Linear(self.n_hidden, self.n_hidden)

        self.E_lstm = nn.LSTM(
            input_size=self.data_embed,
            hidden_size=self.n_hidden,
            num_layers=self.n_layer,
            batch_first=False ## be careful about this batch first false!!!!
        )

    def __reset_hidden__(self, new_batch_size):
        self.hidden = (
            torch.zeros(self.n_layer, new_batch_size, self.n_hidden).double().to(self.opt.device), # h
            torch.zeros(self.n_layer, new_batch_size, self.n_hidden).double().to(self.opt.device)  # c
        )

    def forward(self, x, t):
        re = x.dim() == 4
        if re:
            Domain, B, Seq, Dim = x.shape
            x = x.reshape(Domain * B, Seq, Dim)
            t = t.reshape(Domain * B, -1)

        x = F.relu(self.fc1(x))
        t = F.relu(self.fc1_var(t))
        t = F.relu(self.fc2_var(t))

        t = t.unsqueeze(1)
        t = t.expand(Domain * B, Seq, -1)
        x = torch.cat((x, t), dim=-1)

        # main
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        # x = F.relu(self.fc4(x))
        x = self.fc_final(x)

        # lstm
        x = x.transpose(0, 1)
        batch_size = x.shape[1]
        self.__reset_hidden__(new_batch_size=batch_size)

        _ , (hn, cn) = self.E_lstm(
            x,
            self.hidden
        )
        new_idx = list(range(self.n_layer-1, -1, -1))
        # print(new_idx)
        hn = hn[new_idx,:,:]
        cn = cn[new_idx,:,:]

        hn = torch.cat((hn[0,:,:], hn[1,:,:]), dim=-1)
        cn = torch.cat((cn[0,:,:], cn[1,:,:]), dim=-1)

        encode = torch.cat((hn, cn), dim=-1)

        if re:
            # origin: (Domain * Batch Size, 4 * n_hidden)
            encode = encode.reshape(Domain, B, -1)
            # print("========")
            # print(encode.shape)
            return encode
        else:
            return encode


class GRUSeqPredNet(nn.Module):
    def __init__(self, opt):
        super(GRUSeqPredNet, self).__init__()
        self.opt = opt
        self.n_hidden = opt.num_hidden   
        self.nh_gru = opt.num_hidden # be careful about this code!!
        self.data_embed = opt.data_embed # the data dim for the input of LSTM
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len
        self.input_size = opt.gru_predictor_input # opt.data_embed
        nc = opt.nc        # the classification dim for predictor

        # the predictor
        # I increase the data dimension for 
        self.P_lstm = nn.GRU(
            # input_size=self.data_embed,
            input_size=self.input_size,
            hidden_size=self.nh_gru,
            num_layers=self.n_layer,
            batch_first=False ## be careful about this batch first false!!!!
        )

        self.linear = nn.Linear(self.nh_gru, nc)
        # self.fc_1 = nn.Linear(self.nh_gru, self.nh_gru)

    def forward(self, x):
        # print(x.shape)
        re = (x.dim() == 3)
        if re:
            Domain, B, my_hidden = x.shape
            x = x.reshape(Domain * B, my_hidden)

        # half_my_hidden = int(my_hidden / 2)
        # # be carefull about the dimensonal change!!!
        # h0 = x[:, :half_my_hidden].contiguous()
        # h1 = x[:, half_my_hidden:].contiguous()

        # h = torch.stack((h0, h1), dim=0)

        # for 1 layer
        h = x.unsqueeze(0)

        output, _ = self.P_lstm(
            # seq len * batch * input size
            torch.zeros((self.input_size, Domain * B, self.input_size)).double().to(self.opt.device),
            # torch.zeros((self.data_embed, Domain * B, self.input_size)).double().to(self.opt.device),
            h
        )

        # I am not sure if one linear is enough! may add more layers!
        output = output[-1,:,:]

        # output = F.relu(self.fc_1(output))
        x = self.linear(output)

        # based on the previous success experience, and if doesn't work, try the first one?
        # # x = F.log_softmax(x, dim=1)
        # x_softmax = F.softmax(x, dim=1)
        # x = torch.log(x_softmax + 1e-4)

        if re:
            return x.reshape(Domain, B, -1)
        else:
            return x


class GRUSeqPredValueNet(nn.Module):
    def __init__(self, opt):
        super(GRUSeqPredValueNet, self).__init__()
        self.opt = opt
        self.n_hidden = opt.num_hidden   
        self.nh_gru = opt.num_hidden # be careful about this code!!
        self.data_embed = opt.data_embed # the data dim for the input of LSTM
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len
        self.input_size = 1 # self.data_embed
        # nc = opt.nc        # the classification dim for predictor

        # the predictor
        # I increase the data dimension for 
        self.P_lstm = nn.GRU(
            # input_size=self.data_embed,
            input_size=self.input_size,
            hidden_size=self.nh_gru,
            num_layers=self.n_layer,
            batch_first=False ## be careful about this batch first false!!!!
        )

        self.linear = nn.Linear(self.nh_gru, 1)
        # self.fc_1 = nn.Linear(self.nh_gru, self.nh_gru)

    def forward(self, x):
        # print(x.shape)
        re = (x.dim() == 3)
        if re:
            Domain, B, my_hidden = x.shape
            x = x.reshape(Domain * B, my_hidden)

        # half_my_hidden = int(my_hidden / 2)
        # # be carefull about the dimensonal change!!!
        # h0 = x[:, :half_my_hidden].contiguous()
        # h1 = x[:, half_my_hidden:].contiguous()

        # h = torch.stack((h0, h1), dim=0)

        # for 1 layer
        h = x.unsqueeze(0)
        output, _ = self.P_lstm(
            # seq len * batch * input size
            torch.zeros((1, Domain * B, self.input_size)).double().to(self.opt.device),
            h
        )

        # I am not sure if one linear is enough! may add more layers!
        output = output[-1,:,:]

        # output = F.relu(self.fc_1(output))j
        # be careful about this code! 
        x = ((self.linear(output)) - 2.3).exp_()
        # x = abs(self.linear(output))

        # based on the previous success experience, and if doesn't work, try the first one?
        # x = F.log_softmax(x, dim=1)
        # x_softmax = F.softmax(x, dim=1)
        # x = torch.log(x_softmax + 1e-4)

        if re:
            return x.reshape(Domain, B, -1)
        else:
            return x


class GraphSeqPredNet(nn.Module):
    def __init__(self, opt):
        super(GraphSeqPredNet, self).__init__()
        self.opt = opt
        self.n_hidden = int(opt.num_hidden / 4) # be careful about this code!!
        self.data_embed = opt.data_embed # the data dim for the input of LSTM
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len
        self.input_size = 1 # self.data_embed

        # the predictor
        # I increase the data dimension for 
        self.P_lstm = nn.LSTM(
            # input_size=self.data_embed,
            input_size=self.input_size,
            hidden_size=self.n_hidden,
            num_layers=self.n_layer,
            batch_first=False ## be careful about this batch first false!!!!
        )

        self.linear = nn.Linear(self.n_hidden, 1)

    def forward(self, x):
        # print(x.shape)
        re = (x.dim() == 3)
        if re:
            Domain, B, my_hidden = x.shape
            x = x.reshape(Domain * B, my_hidden)

        quarter_my_hidden = int(my_hidden / 4)
        # be carefull about the dimensonal change!!!
        h0 = x[:, :quarter_my_hidden].contiguous()
        h1 = x[:,quarter_my_hidden: 2 * quarter_my_hidden].contiguous()

        h = torch.stack((h0, h1), dim=0)

        c0 = x[:, 2 * quarter_my_hidden: 3 * quarter_my_hidden].contiguous()
        c1 = x[:, 3 * quarter_my_hidden:].contiguous()

        c = torch.stack((c0, c1), dim=0)

        output, _ = self.P_lstm(
            # seq len * batch * input size
            torch.zeros((1, Domain * B, self.input_size)).double().to(self.opt.device),
            (h, c)
        )

        # I am not sure if one linear is enough! may add more layers!
        output = output[-1,:,:]
        output = self.linear(output)

        if re:
            return output.reshape(Domain, B, -1)
        else:
            return output


class SeqPredNet(nn.Module):
    def __init__(self, opt):
        super(SeqPredNet, self).__init__()
        self.opt = opt
        self.n_hidden = opt.num_hidden 
        self.n_input = opt.num_input
        self.n_layer = opt.num_layer
        self.seq_len = opt.seq_len

         # the predictor
        self.P_lstm = nn.LSTM(
            input_size=self.n_input,
            hidden_size=self.n_hidden,
            num_layers=self.n_layer,
            batch_first=False ## be careful about this batch first false!!!!
        )

        self.linear = nn.Linear(self.n_hidden, 1)

    def forward(self, x):
        # print(x.shape)
        re = (x.dim() == 4)
        if re:
            L, Domain, B, n_hidden = x.shape
            x = x.reshape(-1, Domain * B, n_hidden)

        half_L = int(L / 2)
        h0 = x[0:half_L, :, :]
        c0 = x[half_L:, :, :]

        output, _ = self.P_lstm(
            # seq len * batch * input size
            torch.zeros((1, Domain * B, self.n_input)).double().to(self.opt.device),
            (h0, c0)
        )

        output = output[-1,:,:]
        output = self.linear(output)

        if re:
            return output.reshape(Domain, B, -1)
        else:
            return output


class DiscNet(nn.Module):
    """
    Discriminator doing binary classification: source v.s. target
    """

    def __init__(self, opt):
        super(DiscNet, self).__init__()
        nh = opt.num_hidden

        nin = nh
        self.fc3 = nn.Linear(nin, nh)
        self.bn3 = nn.BatchNorm1d(nh)

        self.fc4 = nn.Linear(nh, nh)
        self.bn4 = nn.BatchNorm1d(nh)

        self.fc5 = nn.Linear(nh, nh)
        self.bn5 = nn.BatchNorm1d(nh)

        self.fc6 = nn.Linear(nh, nh)
        self.bn6 = nn.BatchNorm1d(nh)

        self.fc7 = nn.Linear(nh, nh)
        self.bn7 = nn.BatchNorm1d(nh)

        if opt.no_bn:
            self.bn3 = Identity()
            self.bn4 = Identity()
            self.bn5 = Identity()
            self.bn6 = Identity()
            self.bn7 = Identity()

        self.fc_final = nn.Linear(nh, 1)
        if opt.model in ['ADDA', 'CUA']:
            print('===> Discrinimator Output Activation: sigmoid')
            self.output = lambda x: torch.sigmoid(x)
        else:
            print('===> Discrinimator Output Activation: identity')
            self.output = lambda x: x

    def forward(self, x):
        re = x.dim() == 3

        if re:
            T, B, C = x.shape
            x = x.reshape(T * B, -1)

        x = F.relu(self.bn3(self.fc3(x)))
        x = F.relu(self.bn4(self.fc4(x)))
        x = F.relu(self.bn5(self.fc5(x)))
        x = F.relu(self.bn6(self.fc6(x)))
        x = F.relu(self.bn7(self.fc7(x)))
        x = self.output(self.fc_final(x))

        if re:
            return x.reshape(T, B, -1)
        else:
            return x



class GraphDNet(nn.Module):
    """
    Generate z' for connection loss
    """
    def __init__(self, opt):
        super(GraphDNet, self).__init__()
        nh = opt.num_hidden
        # nin = nh * 4   # 2 * hn and 2 * cn, * 4
        nin = nh
        # nin = int(nh / 2) # for the seq len data
        self.fc3 = nn.Linear(nin, nh)
        self.bn3 = nn.BatchNorm1d(nh)

        self.fc4 = nn.Linear(nh, nh)
        self.bn4 = nn.BatchNorm1d(nh)

        self.fc5 = nn.Linear(nh, nh)
        self.bn5 = nn.BatchNorm1d(nh)

        self.fc6 = nn.Linear(nh, nh)
        self.bn6 = nn.BatchNorm1d(nh)

        self.fc7 = nn.Linear(nh, nh)
        self.bn7 = nn.BatchNorm1d(nh)

        # be careful!! here use dimension of vertex embedding to encode; originally do not have this code
        # self.fc_final = nn.Linear(nh, opt.nt)
        self.fc_final = nn.Linear(nh, opt.nd_out)
        # self.fc_final = nn.Linear(nh, nh)

        if opt.no_bn:
            self.bn3 = Identity()
            self.bn4 = Identity()
            self.bn5 = Identity()
            self.bn6 = Identity()
            self.bn7 = Identity()
    
    def forward(self, x):
        re = x.dim() == 3

        if re:
            T, B, C = x.shape
            x = x.reshape(T * B, -1)

        # print(x.shape)

        x = F.relu(self.bn3(self.fc3(x)))
        x = F.relu(self.bn4(self.fc4(x)))
        x = F.relu(self.bn5(self.fc5(x)))
        x = F.relu(self.bn6(self.fc6(x)))
        x = F.relu(self.bn7(self.fc7(x)))

        # be careful!! here use the dimension of vertex embedding to encode; originally do not have this code
        x = self.fc_final(x)

        if re:
            return x.reshape(T, B, -1)
        else:
            return x


class ClassDiscNet(nn.Module):
    """
    Discriminator doing multi-class classification on the domain
    """

    def __init__(self, opt):
        super(ClassDiscNet, self).__init__()
        nh = opt.num_hidden
        # nc = opt.nc
        nin = nh
        nout = opt.num_domain

        nmid = nh
        # self.cond = None

        print(f'===> Discriminator will distinguish {nout} domains')

        self.fc3 = nn.Linear(nin, nh)
        self.bn3 = nn.BatchNorm1d(nh)

        self.fc4 = nn.Linear(nmid, nh)
        self.bn4 = nn.BatchNorm1d(nh)

        self.fc5 = nn.Linear(nh, nh)
        self.bn5 = nn.BatchNorm1d(nh)

        self.fc6 = nn.Linear(nh, nh)
        self.bn6 = nn.BatchNorm1d(nh)

        self.fc7 = nn.Linear(nh, nh)
        self.bn7 = nn.BatchNorm1d(nh)

        if opt.no_bn:
            self.bn3 = Identity()
            self.bn4 = Identity()
            self.bn5 = Identity()
            self.bn6 = Identity()
            self.bn7 = Identity()

        self.fc_final = nn.Linear(nh, nout)

    def forward(self, x): # , f_exp):
        re = x.dim() == 3

        if re:
            T, B, C = x.shape
            x = x.reshape(T * B, -1)
            # f_exp = f_exp.reshape(T * B, -1)

        x = F.relu(self.bn3(self.fc3(x)))
        # if self.cond is not None:
        #     f = self.cond(f_exp)
        #     x = torch.cat([x, f], dim=1)
        x = F.relu(self.bn4(self.fc4(x)))
        x = F.relu(self.bn5(self.fc5(x)))
        x = F.relu(self.bn6(self.fc6(x)))
        x = F.relu(self.bn7(self.fc7(x)))
        x = F.relu(self.fc_final(x))
        x = torch.log_softmax(x, dim=1)
        if re:
            return x.reshape(T, B, -1)
        else:
            return x


class CondClassDiscNet(nn.Module):
    """
    Discriminator doing multi-class classification on the domain
    """

    def __init__(self, opt):
        super(CondClassDiscNet, self).__init__()
        nh = opt.num_hidden
        # nc = opt.nc
        nin = nh
        nout = opt.num_domain
        nc = opt.seq_len

        nmid = nh * 2
        self.cond = nn.Sequential(
            nn.Linear(nc, nh),
            nn.ReLU(True),
            nn.Linear(nh, nh),
            nn.ReLU(True),
        )
        # self.cond = None

        print(f'===> Discriminator will distinguish {nout} domains')

        self.fc3 = nn.Linear(nin, nh)
        self.bn3 = nn.BatchNorm1d(nh)

        self.fc4 = nn.Linear(nmid, nh)
        self.bn4 = nn.BatchNorm1d(nh)

        self.fc5 = nn.Linear(nh, nh)
        self.bn5 = nn.BatchNorm1d(nh)

        self.fc6 = nn.Linear(nh, nh)
        self.bn6 = nn.BatchNorm1d(nh)

        self.fc7 = nn.Linear(nh, nh)
        self.bn7 = nn.BatchNorm1d(nh)

        if opt.no_bn:
            self.bn3 = Identity()
            self.bn4 = Identity()
            self.bn5 = Identity()
            self.bn6 = Identity()
            self.bn7 = Identity()

        self.fc_final = nn.Linear(nh, nout)

    def forward(self, x, f_sig): # , f_exp):
        re = x.dim() == 3
        if re:
            T, B, C = x.shape
            x = x.reshape(T * B, -1)
            f_sig = f_sig.reshape(T * B, -1)
            # f_exp = f_exp.reshape(T * B, -1)

        x = F.relu(self.bn3(self.fc3(x)))
        # if self.cond is not None:
        f = self.cond(f_sig)

        x = torch.cat([x, f], dim=1)

        x = F.relu(self.bn4(self.fc4(x)))
        x = F.relu(self.bn5(self.fc5(x)))
        x = F.relu(self.bn6(self.fc6(x)))
        x = F.relu(self.bn7(self.fc7(x)))
        x = F.relu(self.fc_final(x))
        x = torch.log_softmax(x, dim=1)
        if re:
            return x.reshape(T, B, -1)
        else:
            return x